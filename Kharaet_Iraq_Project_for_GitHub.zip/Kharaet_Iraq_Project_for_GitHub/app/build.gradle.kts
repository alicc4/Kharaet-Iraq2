plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.ali.kharaetiraq
    compileSdk = 35
    defaultConfig {
        applicationId = "com.ali.kharaetiraq
        minSdk = 24
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
dependencies {
    implementation("org.osmdroid:osmdroid-android:6.1.20")
}
