package com.ali.kharaetiraq

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.graphics.Color
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Marker
import org.osmdroid.views.overlay.Polyline
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URLEncoder
import java.net.URL
import java.util.Locale
import kotlin.concurrent.thread

class MainActivity : Activity(), LocationListener {
    private lateinit var map: MapView
    private lateinit var status: TextView
    private lateinit var destination: EditText
    private lateinit var locationManager: LocationManager
    private var current: GeoPoint? = null
    private var routeLine: Polyline? = null
    private var tts: TextToSpeech? = null
    private var lastRerouteAt = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Configuration.getInstance().userAgentValue = packageName
        tts = TextToSpeech(this) { result ->
            if (result == TextToSpeech.SUCCESS) tts?.language = Locale("ar")
        }
        locationManager = getSystemService(LOCATION_SERVICE) as LocationManager

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(5, 13, 24))
            setPadding(18, 18, 18, 10)
        }
        val title = TextView(this).apply {
            text = "خرائط العراق"
            textSize = 26f; setTextColor(Color.rgb(235, 181, 76))
            gravity = Gravity.CENTER; setPadding(0, 6, 0, 4)
        }
        val subtitle = TextView(this).apply {
            text = "ملاحتك الذكية داخل العراق • علي حاكم عزاوي"
            textSize = 12f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            setPadding(0, 0, 0, 12)
        }
        destination = EditText(this).apply {
            hint = "اكتب المكان أو المدينة..."
            textSize = 16f; setSingleLine(true)
            setTextColor(Color.WHITE); setHintTextColor(Color.LTGRAY)
            setPadding(14, 4, 14, 4)
            setBackgroundColor(Color.rgb(19, 33, 49))
        }
        val search = Button(this).apply {
            text = "ابحث وارسم الطريق"
            setOnClickListener { searchAndRoute(destination.text.toString().trim()) }
        }
        status = TextView(this).apply {
            text = "جاهز • فعّل الموقع للبدء"
            textSize = 13f; setTextColor(Color.rgb(235, 181, 76))
            gravity = Gravity.CENTER; setPadding(0, 7, 0, 7)
        }
        map = MapView(this).apply {
            setTileSource(TileSourceFactory.MAPNIK)
            setMultiTouchControls(true)
            controller.setZoom(6.0)
            controller.setCenter(GeoPoint(33.3152, 44.3661))
        }
        val speed = TextView(this).apply {
            text = "السرعة: -- كم/س"
            textSize = 16f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            setPadding(0, 8, 0, 8)
        }
        val footer = TextView(this).apply {
            text = "المصمم علي حاكم عزاوي كاظم"
            textSize = 11f; setTextColor(Color.LTGRAY); gravity = Gravity.CENTER
        }
        root.addView(title)
        root.addView(subtitle)
        root.addView(destination, LinearLayout.LayoutParams(-1, 52))
        root.addView(search)
        root.addView(status)
        root.addView(map, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(speed)
        root.addView(footer)
        setContentView(root)
        requestLocation()
    }

    private fun requestLocation() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), 101)
            return
        }
        try {
            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 2500L, 5f, this)
            val last = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER)
            if (last != null) onLocationChanged(last)
        } catch (_: Exception) {
            status.text = "تعذر تحديد الموقع؛ تأكد من تشغيل GPS"
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 101 && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) requestLocation()
        else status.text = "اسمح للتطبيق باستخدام الموقع حتى يعمل التوجيه"
    }

    override fun onLocationChanged(location: Location) {
        current = GeoPoint(location.latitude, location.longitude)
        if (::map.isInitialized) {
            val speedView = findTextViewWithPrefix(window.decorView, "السرعة:")
            speedView?.text = "السرعة: ${if (location.hasSpeed()) (location.speed * 3.6).toInt() else 0} كم/س"
            if (routeLine != null && System.currentTimeMillis() - lastRerouteAt > 15000) {
                val nearest = routeLine!!.actualPoints.minByOrNull { it.distanceToAsDouble(current!!) }
                if (nearest != null && nearest.distanceToAsDouble(current!!) > 180) {
                    lastRerouteAt = System.currentTimeMillis()
                    searchAndRoute(destination.text.toString().trim(), true)
                }
            }
        }
    }

    private fun findTextViewWithPrefix(view: View, prefix: String): TextView? {
        if (view is TextView && view.text.toString().startsWith(prefix)) return view
        if (view is android.view.ViewGroup) for (i in 0 until view.childCount) {
            val found = findTextViewWithPrefix(view.getChildAt(i), prefix)
            if (found != null) return found
        }
        return null
    }

    private fun searchAndRoute(query: String, silent: Boolean = false) {
        if (query.isBlank()) {
            if (!silent) Toast.makeText(this, "اكتب اسم المكان أولاً", Toast.LENGTH_SHORT).show()
            return
        }
        val origin = current
        if (origin == null) {
            status.text = "بانتظار تحديد موقعك عبر GPS"
            return
        }
        status.text = "جاري البحث عن الطريق..."
        thread {
            try {
                val encoded = URLEncoder.encode(query, "UTF-8")
                val geocodeUrl = URL("https://nominatim.openstreetmap.org/search?q=$encoded&format=json&limit=1&countrycodes=iq")
                val geoConn = geocodeUrl.openConnection() as HttpURLConnection
                geoConn.setRequestProperty("User-Agent", "KharaetIraq/1.0")
                geoConn.connectTimeout = 10000; geoConn.readTimeout = 10000
                val geoText = geoConn.inputStream.bufferedReader().use { it.readText() }
                geoConn.disconnect()
                val arr = org.json.JSONArray(geoText)
                if (arr.length() == 0) throw Exception("لم نعثر على المكان داخل العراق")
                val item = arr.getJSONObject(0)
                val lat = item.getDouble("lat"); val lon = item.getDouble("lon")
                val routeUrl = URL("https://router.project-osrm.org/route/v1/driving/${origin.longitude},${origin.latitude};$lon,$lat?overview=full&geometries=geojson")
                val routeConn = routeUrl.openConnection() as HttpURLConnection
                routeConn.connectTimeout = 15000; routeConn.readTimeout = 15000
                val routeText = routeConn.inputStream.bufferedReader().use { it.readText() }
                routeConn.disconnect()
                val routeJson = JSONObject(routeText).getJSONArray("routes").getJSONObject(0)
                val coords = routeJson.getJSONObject("geometry").getJSONArray("coordinates")
                val points = ArrayList<GeoPoint>()
                for (i in 0 until coords.length()) {
                    val c = coords.getJSONArray(i)
                    points.add(GeoPoint(c.getDouble(1), c.getDouble(0)))
                }
                runOnUiThread {
                    routeLine?.let { map.overlays.remove(it) }
                    routeLine = Polyline().apply {
                        setPoints(points)
                        outlinePaint.color = Color.rgb(40, 170, 255)
                        outlinePaint.strokeWidth = 10f
                    }
                    map.overlays.add(routeLine)
                    val marker = Marker(map)
                    marker.position = GeoPoint(lat, lon)
                    marker.title = query
                    map.overlays.removeAll { it is Marker }
                    map.overlays.add(marker)
                    map.zoomToBoundingBox(routeLine!!.bounds, true, 60)
                    map.invalidate()
                    val km = routeJson.getDouble("distance") / 1000.0
                    val mins = routeJson.getDouble("duration") / 60.0
                    status.text = "المسافة ${"%.1f".format(km)} كم • تقريباً ${mins.toInt()} دقيقة"
                    tts?.speak("تم تحديد الطريق إلى $query", TextToSpeech.QUEUE_FLUSH, null, "route")
                }
            } catch (e: Exception) {
                runOnUiThread { status.text = "تعذر إيجاد الطريق: ${e.message ?: "تحقق من الإنترنت"}" }
            }
        }
    }

    override fun onResume() { super.onResume(); if (::map.isInitialized) map.onResume() }
    override fun onPause() { if (::map.isInitialized) map.onPause(); super.onPause() }
    override fun onDestroy() { tts?.shutdown(); super.onDestroy() }
}
